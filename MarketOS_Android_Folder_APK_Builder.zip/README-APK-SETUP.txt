MarketOS Android folder APK builder

This ZIP is structured for your existing GitHub repository. It keeps all Android build files under android/ and the GitHub Actions workflow under .github/workflows/.

Expected layout after upload:
marketos-onefile/
  android/
    www/
      index.html
    package.json
    capacitor.config.json
  .github/
    workflows/
      build-apk.yml

Upload/merge these folders into the repository root. Do not upload only the ZIP.
Then open GitHub > Actions > Build MarketOS APK > Run workflow.
After a successful run, download the MarketOS-debug-APK artifact and extract app-debug.apk.

Important:
- This is a debug/test APK, not a Play Store release.
- The HTML is included at android/www/index.html; replace it with your own current index HTML if this is not the intended latest file.
- Ensure the Supabase Project URL and publishable key are configured in the HTML. Never put a service_role/secret key in a client app.
- APK build success does not mean every backend feature has been fully implemented or tested.
